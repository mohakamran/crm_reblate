<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script>document.write(new Date().getFullYear())</script> © Reblate Solutions.
            </div>
            <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                    Developed  by <a  target="_blank" href="https://reblatesols.com">Reblate Solutions</a>
                </div>
            </div>
        </div>
    </div>
</footer>
