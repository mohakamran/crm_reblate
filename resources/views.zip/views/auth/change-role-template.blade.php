<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Email Template</title>
    
</head>

<body>
    <p> Dear <b>{{$userName}}</b>,</p>
    <p>

         It is to inform you that Your role has been changed by Admin  from <b>{{$userRoleOld}}</b> to <b>{{$userRole}}</b> .
        Please log in to your account at CRM using the provided credentials. 

    </p>

    <p>Thank you so much!</p>
    <p>Best regards,<br>
     M.Abuzar<br>
     Website: https://reblatesols.com/ <br>
     </p>
</body>

</html>
